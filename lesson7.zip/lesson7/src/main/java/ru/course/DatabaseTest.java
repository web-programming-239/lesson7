package ru.course;

import ru.course.data.*;
import ru.course.data.dbmock.DatabaseMock;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DatabaseTest {
    public static void main(String[] args) throws ParseException {
        Database db = new MariaDB();
        System.out.println("reservations:");
        db.getReservations().forEach(System.out::println);
        System.out.println();

        System.out.println("rooms:");
        db.getRooms().forEach(System.out::println);
        System.out.println();

        System.out.println("teachers:");
        db.getTeachers().forEach(System.out::println);
        System.out.println();

        String d1 = "01.02.2023";
        String d2 = "01.10.2023";
        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
        System.out.println("Reservations from " + d1 + " to " + d2 + ":");
        db.getReservations(format.parse(d1), format.parse(d2)).forEach(System.out::println);
        System.out.println();

        testInsert(db);
        testDelete(db);
    }


    public static void testInsert(Database db) {
        db.addTeacher(new Teacher("test test1 test2"));
        db.saveReservation(new Reservation("208", 2, "test123",
                new Date(),
                new Date()));
        db.addRoom(new Room("123", 1, 10));
        Teacher t = new Teacher("1 2 3");
        t.setId(1);
        db.updateTeacher(t);

    }

    public static void testDelete(Database db) {
        db.deleteReservation(1);
    }
}
