package ru.course.data;

import java.util.Date;
import java.util.List;

public interface Database {
    void saveReservation(Reservation reservation);

    void deleteReservation(int reservationId);

    void addTeacher(Teacher teacher);

    void addRoom(Room room);

    void updateTeacher(Teacher teacher);

    List<Reservation> getReservations();

    List<Reservation> getReservations(Date startTime, Date endTime);

    List<Room> getRooms();

    List<Teacher> getTeachers();

}
