package ru.course.data;

import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class MariaDB implements Database {

    @Override
    public void saveReservation(Reservation reservation) {

    }

    @Override
    public void deleteReservation(int reservationId) {

    }

    @Override
    public void addTeacher(Teacher teacher) {

    }

    @Override
    public void addRoom(Room room) {

    }

    @Override
    public void updateTeacher(Teacher teacher) {

    }

    @Override
    public List<Reservation> getReservations() {
        return null;
    }

    @Override
    public List<Reservation> getReservations(Date startTime, Date endTime) {
        return null;
    }

    @Override
    public List<Room> getRooms() {
        return null;
    }

    @Override
    public List<Teacher> getTeachers() {
        return null;
    }
}
