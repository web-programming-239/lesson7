package ru.course.data;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Reservation extends DatabaseObject{
    private String classNumber;
    private int teacherId;
    private String purpose;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd.MM.yyyy HH:mm", timezone = "GMT+3")
    private Date startTime;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd.MM.yyyy HH:mm", timezone = "GMT+3")
    private Date endTime;

    public Reservation(String classNumber, int teacherId, String purpose, Date startTime, Date endTime) {
        this.classNumber = classNumber;
        this.teacherId = teacherId;
        this.purpose = purpose;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public String getClassNumber() {
        return classNumber;
    }

    public void setClassNumber(String classNumber) {
        this.classNumber = classNumber;
    }

    public int getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    @Override
    public String toString() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy hh:mm");
        return "Reservation(" +
            classNumber + ", " +
            teacherId + ", " +
            purpose + ", " +
            simpleDateFormat.format(startTime) + ", " +
            simpleDateFormat.format(endTime) + ")";
    }
}
