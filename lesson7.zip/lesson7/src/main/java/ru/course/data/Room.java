package ru.course.data;

public class Room extends DatabaseObject {
    private String classNumber;
    private int floorNumber;
    private int capacity;

    public Room(String classNumber, int floorNumber, int capacity) {
        this.classNumber = classNumber;
        this.floorNumber = floorNumber;
        this.capacity = capacity;
    }

    public String getClassNumber() {
        return classNumber;
    }

    public void setClassNumber(String classNumber) {
        this.classNumber = classNumber;
    }

    public int getFloorNumber() {
        return floorNumber;
    }

    public void setFloorNumber(int floorNumber) {
        this.floorNumber = floorNumber;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    @Override
    public String toString() {
        return "Room(" +
                classNumber + ", " +
                floorNumber + ", " +
                capacity + ")";
    }
}
