package ru.course.data;

public class Teacher extends DatabaseObject {
    private String fullName;

    public Teacher(String fullName) {
        this.fullName = fullName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    @Override
    public String toString() {
        return "Teacher("  + fullName + ")";
    }
}
