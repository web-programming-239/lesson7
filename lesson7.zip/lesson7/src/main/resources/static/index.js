function get(url, args, callback) {
    // Эта функция делает запрос на сервер

    // url - интуитивно понятно, что это такое - адрес, по которому хотим сделать запрос.
    // args - аргументы запроса.
    // callback - функция, которая будет вызвана, когда придет ответ от сервера.
    // В неё передадим ответ сервера.
    url += "?"
    const serialized_args = []
    for (const key in args) {
        serialized_args.push(key + "=" + args[key])
    }
    url += serialized_args.join("&")
    $.get(url, callback)
}

function post(url, args, callback) {
    $.post(url, args).always(callback)
}

function updateDropdown(select, objects, attrName) {
    objects.forEach((obj) => {
        select.append($("<option></option>").attr("value", obj.id).text(obj[attrName]))
    })

}

function updateTeachersDropdown(teachers) {
    updateDropdown($("#teacher"), teachers, "fullName")

}

function updateRoomsDropdown(rooms) {
    return updateDropdown($("#cabinet"), rooms, "classNumber")
}

